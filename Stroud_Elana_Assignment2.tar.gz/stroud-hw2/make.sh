#!/bin/bash


echo -e "\nCompiling Part 1: CoinFlip.java \n"
javac code/part1/CoinFlip.java

echo -e "\nCompiling Part 2: BruteForceDES.java \n"
javac code/part2/BruteForceDES.java
