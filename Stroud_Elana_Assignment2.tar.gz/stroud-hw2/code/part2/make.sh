#!/bin/bash

rm BruteForceDES.class
javac BruteForceDES.java
