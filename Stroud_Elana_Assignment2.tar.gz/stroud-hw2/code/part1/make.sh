#!/bin/bash

rm CoinFlip.class
javac CoinFlip.java